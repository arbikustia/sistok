<?php

namespace Mpdf\Tag;

class Em extends InlineTag
{


}
